<div align="center"><h1>Requirements 🙌🏾✨</h1></div> 

Hello, 🤩👋🏾 Thank you for downloading or using this template, we hope you like it. Please link back to us if you have used this template by adding your portfolio to the list in the README <a href="https://github.com/CommunityPro/portfolio-html#examples">here</a>, we would love to see how you used or customized your portfolio. 😇

These are not requirements per se, see them as giving back to the efforts of the community and the members who built this project.

## 1. Star the project
This helps push the project to attract more contributors and users like yourself who might benefit from the project.

## 2. Fork the project
Forking this project is another way of supporting our work and is a good way to customize the project to your taste.

If you are planning to customize this project, push your changes to a new branch called `dev` so you can keep receiving updates on the main branch when we make any changes.

## 3. Sponsor
This is one of the biggest ways you can support our work. Buy us a coffee or two and we will strongly appreciate it.

<div align="center">
  <a href="https://www.buymeacoffee.com/evavic44">
    <img width="150px" alt="bmc-button" src="https://user-images.githubusercontent.com/62628408/127788747-8850d386-fc61-4fff-b18f-8c5ee597be34.png">
  </a>
<a href="https://www.buymeacoffee.com/evavic44"><img width="150px" height="100%" src="https://img.shields.io/badge/sponsor-30363D?style=for-the-badge&logo=GitHub-Sponsors&logoColor=#white"></a>
</div>

<div align="center">
<h2>Happy Coding 🌟🙌🏾</h2>
</div>
